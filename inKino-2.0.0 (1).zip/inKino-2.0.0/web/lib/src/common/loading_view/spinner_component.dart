import 'package:angular/angular.dart';

@Component(
  selector: 'spinner',
  templateUrl: 'spinner_component.html',
  styleUrls: ['spinner_component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
)
class SpinnerComponent {}
