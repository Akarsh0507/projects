enum LoadingStatus {
  idle,
  loading,
  error,
  success,
}