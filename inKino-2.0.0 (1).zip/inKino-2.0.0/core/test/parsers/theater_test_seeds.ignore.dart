const String theatersXml = '''<?xml version="1.0"?>
<TheatreAreas xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <TheatreArea>
        <ID>1029</ID>
        <Name>Valitse alue/teatteri</Name>
    </TheatreArea>
    <TheatreArea>
        <ID>001</ID>
        <Name>Gotham: THEATER ONE</Name>
    </TheatreArea>
    <TheatreArea>
        <ID>002</ID>
        <Name>Gotham: THEATER TWO</Name>
    </TheatreArea>
</TheatreAreas>''';
